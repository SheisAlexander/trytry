<?php
require "userlevel.php";
$db = new userlevel();

if (isset($_POST['username']) && isset($_POST['english_id'])) {
    if ($db->dbConnect()) {
        if ($db->update("users", $_POST['username'], $_POST['english_id'])) {
            echo "update Success";
        } else echo "Username or Password wrong";
    } else echo "Error: Database connection";
} else echo "All fields are required";

//if (empty($_POST['username'] || empty($_POST['current_englishid']))) {
  //  die('field');
 // }
 // $username  = $_POST['username '];
 // $current_englishid = $_POST['current_englishid'];
 // $sql = 'UPDATE users SET current_englishid = $current_englishid where username =$username';

//if ($conn->query($sql) === TRUE) {
 // echo "Record updated successfully";
//} else {
// echo "Error updating record: " . $conn->error;
//}

?>



