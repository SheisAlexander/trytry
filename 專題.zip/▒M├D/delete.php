<?php
require "deleteword.php";
$db = new deleteword();

if (isset($_POST['user_id']) && isset($_POST['word'])) {
    if ($db->dbConnect()) {
        if ($db->delete("collectword", $_POST['user_id'], $_POST['word'])) {
            echo "delete Success";
        } else echo "already deleted";
    } else echo "Error: Database connection";
} else echo "All fields are required";

//if (empty($_POST['username'] || empty($_POST['current_englishid']))) {
  //  die('field');
 // }
 // $username  = $_POST['username '];
 // $current_englishid = $_POST['current_englishid'];
 // $sql = 'UPDATE users SET current_englishid = $current_englishid where username =$username';

//if ($conn->query($sql) === TRUE) {
 // echo "Record updated successfully";
//} else {
// echo "Error updating record: " . $conn->error;
//}

?>