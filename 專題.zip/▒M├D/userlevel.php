<?php
require "levelConfig.php";

class userlevel
{
    public $connect;
    public $data;
    private $sql;
    protected $servername;
    protected $username;
    protected $password;
    protected $databasename;

    public function __construct()
    {
        $this->connect = null;
        $this->data = null;
        $this->sql = null;
        $dbc = new levelConfig();
        $this->servername = $dbc->servername;
        $this->username = $dbc->username;
        $this->password = $dbc->password;
        $this->databasename = $dbc->databasename;
    }

    function dbConnect()
    {
        $this->connect = mysqli_connect($this->servername, $this->username, $this->password, $this->databasename);
        return $this->connect;
    }

    function prepareData($data)
    {
        return mysqli_real_escape_string($this->connect, stripslashes(htmlspecialchars($data)));
    }

   
	
	function update($table, $username, $english_id)
    {
        $username = $this->prepareData($username);
        $current_englishid = $this->prepareData($english_id);
        $this->sql = "UPDATE $table SET english_id = '$english_id' where username ='$username'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $dbusername = $row['username'];
            $dbenglishid = $row['english_id'];
            if ($dbusername == $username && $dbenglish_id==$english_id) {
                $update = true;
            } else $update= false;
        } else $update = false;

        return $update;
    }


}

?>
